<template>
  <div id="dingdian" style="width:100%;text-align: center" name = 'topn'>
    <el-row type="flex" justify="center">
      <el-col :span="3"><div class="longdiwei"><img src="../../common/images/logo.png" class="width:100%"/></div></el-col>
      <el-col :span="12">
        <div class="heitiedingwei">
        <div class="navitem">
        <ul ref="vul" class="nav_ul">
          <li><router-link to="/home" class="lia" @mouseenter.native="tagshow($event)" @mouseleave.native="closehr($event)">{{navitem.myhome}}</router-link>
            <transition><hr v-show="vif[0].cut" class="navhr"/></transition>
          </li>
          <li><router-link to="/coop" class="lia" @mouseenter.native="tagshow($event)" @mouseleave.native="closehr($event)">{{navitem.hezuo}}</router-link>
            <transition><hr v-show="vif[1].cut" class="navhr"/></transition>
          </li>
          <li><router-link to="/news" class="lia" @mouseenter.native="tagshow($event)" @mouseleave.native="closehr($event)">{{navitem.zixun}}</router-link>
            <transition> <hr v-show="vif[2].cut" class="navhr"/></transition>
          </li>
          <li><router-link to="/recruit" class="lia"  @mouseenter.native="tagshow($event)" @mouseleave.native="closehr($event)">{{navitem.zhaopin}}</router-link>
            <transition><hr v-show="vif[3].cut" class="navhr"/></transition>
          </li>
          <li><router-link to="/about" class="lia" @mouseenter.native="tagshow($event)" @mouseleave.native="closehr($event)">{{navitem.aboutus}}</router-link>
            <transition><hr v-show="vif[4].cut" class="navhr"/></transition>
          </li>

        </ul>
        </div>
          <el-row class="tac">

            <el-col :span="7">
              <el-menu
                default-active="2"
                class="el-menu-vertical-demo"
                @open="handleOpen"
                @close="handleClose"
                background-color="#013e27"
                text-color="#fff"
                active-text-color="#ffd04b">
                <el-submenu index="1">
                  <template slot="title">
                    <span>导航</span>
                  </template>
                  <el-menu-item-group style="width: 10rem">
                    <el-menu-item index="1-1">首页</el-menu-item>
                    <el-menu-item index="1-2">平台合作</el-menu-item>
                    <el-menu-item index="1-3">新闻资讯</el-menu-item>
                    <el-menu-item index="1-4">招贤纳士</el-menu-item>
                    <el-menu-item index="1-5">关于我们</el-menu-item>
                  </el-menu-item-group>
                </el-submenu>
              </el-menu>
            </el-col>
          </el-row>

        </div>
      </el-col>
    </el-row>





   </div>






<!--  </div>-->
</template>

<script>

   export default {
        name: "Banner",
     data(){
          return{
            navitem:{
              myhome:'首页',
              hezuo:'平台合作',
              zixun:'新闻资讯',
              zhaopin:'招贤纳士',
              aboutus:'关于我们'
            },
            jiluid:'',
            vif:[
              {
                cut:false
               },
              {
                cut:false
              },
              {
                cut:false
              },
              {
                cut:false
              },
              {
                cut:false
              },
            ],
            liarr:[],
          }
     },
     methods:{
       changevif(g){
            this.vif[g].cut = !this.vif[g].cut
          },
       tagshow(e){
         for (let i = 0; i < this.liarr.children.length; i++){
              // console.log(this.liarr.children[i])
              if (this.liarr.children[i].children[0].innerText == e.currentTarget.innerText){
                    this.jiluid = i
                      this.changevif(i)
              }
         }
       },
       closehr(){
         this.changevif(this.jiluid)
       },
       getLiarr(){
         this.liarr = this.$refs.vul;
       },
       handleOpen(key, keyPath) {
         console.log(key, keyPath);
       },
       handleClose(key, keyPath) {
         console.log(key, keyPath);
       },
     },
     mounted(){
       this.getLiarr()
     }
    }
</script>

<style>
  .el-menu-vertical-demo{
    width: 10rem;
    border: 0rem;
  }

  .navdingwei{
    width: 100%;
    position: absolute;
    top: 0rem;
    left:0rem;
    text-align: center;
  }
.navCanton{
  /*width: 75rem;*/
  /*height: 3rem;*/
}
.navton {
    margin: 0 auto;
}
.nav_imgtain {
  float:left;
  padding-top: 0.7rem;
}
  .navitem {
  float: right;
  }
  .navitem .nav_ul{
    list-style: none;
    margin-top: 1.43rem;
  }
  .navitem .nav_ul li{
    float: left;
    margin-left: 2.06rem;
    color: white;
    font-family: '微软雅黑';
  }
  .navhr {
    height:1px;
    margin-top: 0.5rem;
    margin-bottom: 0rem;
    border-top:0.2rem solid #ffffff;
  }
  .lia {
    color: white;
    font-size: 1rem;
  }
  .lia:link, .lia:hover, .lia:visited, .lia:active {
    color: white;
    font-size: 1rem;
    text-decoration:none;
  }
  .v-enter,.v-leave-to {
    width: 0;



  }
  .v-leave,.v-enter-to {
    width: 100%;




  }
  .v-enter-active,.v-leave-active {
      transition: all 1s ease;
    /*transition: color 1s ease;*/
  }
@media screen and (max-width: 1000px){
  .navitem{
    display: none;
  }
  .tac{
    display: block;
  }
  .heitiedingwei{
    float: right;
  }
}
@media screen and (min-width: 1001px) {
  .navitem{
    display: block;
  }
  .tac{
    display: none;
  }
}
.tac{

}
  .longdiwei{
    margin-top: 1rem;
    text-align: left;
  }
</style>
