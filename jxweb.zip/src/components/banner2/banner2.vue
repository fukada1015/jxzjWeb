<template>

  <div class="bannerbg">
      <el-row type="flex" justify="center" class="banmiandingxing">
        <el-col :span="12"><div class="wow bannertupiandingwei" data-wow-delay=".6s"><img src="../../common/images/wz.png" style="width: 550px"/></div></el-col>
        <el-col :span="12"><div>
            <div class="wow bannerrightdd bannerimgainimation" data-wow-delay=".9s">
              <img src="../../common/images/afafa.png"/></div>
        </div></el-col>
      </el-row>
<!--    <div class="container">-->
<!--      <div class="row">-->
<!--        <div class="wow row1" data-wow-delay=".6s"><img src="../../common/images/wz.png" class="img-responsive" /></div>-->
<!--        <div class="wow row2" data-wow-delay=".8s"><img src="../../common/images/afafa.png" class="img-responsive"/></div>-->
<!--      </div>-->
<!--    </div>-->
  </div>
</template>

<script>
  import Icon from 'vue2-svg-icon/Icon.vue'
    export default {
        name: "banner2",
      components:{
        Icon,
      },
    }
</script>

<style>
  .bancomputer{
    position: absolute;
    left: 250px;
    top: 50px;
  }
  .bancomputer img{
    width: 164px;
  }
  .bandipian1{
    position: absolute;
    left: 400px;
    top: 20px;
  }
  .bandipian1 img{
    width: 110px;
  }
  .bannerrightdd{
    position: relative;
  }
  .bannerimgainimation{
    -webkit-animation-name: -webkit-bannerimgainimation;
    animation-name: bannerimgainimation;
  }
  @keyframes -webkit-bannerimgainimation{
    0% {
      opacity: 0;
      -webkit-transform: translateX(32px);
      transform: translateX(32px);
    }

    100% {
      opacity: 1;
      -webkit-transform: translateX(0);
      transform: translateX(0);

    }
  }
  @keyframes bannerimgainimation{
    0% {
      opacity: 0;
      -webkit-transform: translateX(32px);
      -ms-transform: translateX(32px);
      transform: translateX(32px);
    }

    100% {
      opacity: 1;
      -webkit-transform: translateX(0);
      -ms-transform: translateX(0);
      transform: translateX(0);
    }
  }
  .bannerrightdd img{
   width: 550px;
  }
  .bannerbg{
    background: url("../../common/images/bar1bg_01.jpg") no-repeat top center;
    padding-bottom: 8rem;
    padding-top: 8rem;
  }
  .banmiandingxing{
    max-width: 1200px;
    margin: 0 auto;
  }
  .bannertupiandingwei{
    padding-top: 8rem;
    -webkit-animation-name: -webkit-bannertupiandingwei;
    animation-name: bannertupiandingwei;
  }
  .bannertupiandingwei img {
    width: 396px;
    height: auto;
  }
  @keyframes -webkit-bannertupiandingwei{
    0% {
      opacity: 0;
      -webkit-transform: translateX(-32px);
      transform: translateX(-32px);
    }

    100% {
      opacity: 1;
      -webkit-transform: translateX(0);
      transform: translateX(0);

    }
  }
  @keyframes bannertupiandingwei{
    0% {
      opacity: 0;
      -webkit-transform: translateX(-32px);
      -ms-transform: translateX(-32px);
      transform: translateX(-32px);
    }

    100% {
      opacity: 1;
      -webkit-transform: translateX(0);
      -ms-transform: translateX(0);
      transform: translateX(0);
    }
  }
.banertain {
  width: 100%;
  height: auto;
  background: url("../../common/images/bar1bg_01.jpg") no-repeat center;
  /*height: 53rem;*/
}
  .bannerguolv {
    width: 75rem;
    overflow: hidden;
    height: 53rem;
  }
  .row1{
    opacity:0;
    top: 15rem;
    position: relative;
    animation:mymove 2s;
    animation-fill-mode: forwards;
    animation-delay:.6s;

  }
@keyframes mymove
{
  from {left:-1rem;opacity: 0}
  to {left:1rem;opacity: 1}
}
@-webkit-keyframes mymove /*Safari and Chrome*/
{
  from {left:-1rem;opacity: 0}
  to {left:1rem;opacity: 1}
}
.row2{
  opacity:0;
  top: 5rem;
  left: -3rem;
  position:relative;
  animation:mymove2 2s;
  animation-fill-mode: forwards;
  animation-delay:.6s;

}
@keyframes mymove2
{
  from {top:5rem;opacity: 0;left: 33rem}
  to {top:5rem;opacity: 1;left: 31rem}
}
@-webkit-keyframes mymove /*Safari and Chrome*/
{
  from {top:5rem;opacity: 0;left: 33rem}
  to {top:22rem;opacity: 1;left: 31rem}
}
</style>
