<template>
    <div class="dingbujiantou">
      <div style="text-align: center"><a href="#dingdian"><img src="../../common/images/backtop_03.png"/></a></div>
    </div>
</template>

<script>
    export default {
        name: "fanhuiding"
    }
</script>

<style>
.dingbujiantou{
  width: 40px;
  height: 40px;
  position: fixed;
  bottom: 20px;
  right: 20px;
  /*background-color: black;*/
  opacity: 0.7;
  color: white;
}
</style>
