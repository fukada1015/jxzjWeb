<template>
    <div class="jxzj_hzmsbg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 wow hzms1 hzms1animation" data-wow-delay="1s"><span>供应商伙伴和机械之家的合作模式</span></div>
        </div>
        <div class="row">
          <div class="hzms_line"></div>
        </div>
        <div class="row">
          <div class="wow hzmsimg hzmsimganimation" data-wow-delay="1.2s"><img src="../../common/images/hzmsimg_06.png"/></div>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "jxzj_hzms"
    }
</script>

<style>
.jxzj_hzmsbg{
  background-color: #e6f3f2;
  padding-top: 5rem;
  padding-bottom: 2rem;
}
  .hzms1{
    margin: 0 auto;
    letter-spacing: 0.2rem;
    color: #48b9a6;
    text-align: center;
    font-size: 1.6rem;
  }
  .hzms1animation{
    -webkit-animation-name: -webkit-hzms1animation;
    animation-name: hzms1animation;
  }
@keyframes -webkit-hzms1animation{
  0% {
    opacity: 0;
    -webkit-transform: translateX(32px);
    transform: translateX(32px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateX(0);
    transform: translateX(0);

  }
}
@keyframes hzms1animation{
  0% {
    opacity: 0;
    -webkit-transform: translateX(32px);
    -ms-transform: translateX(32px);
    transform: translateX(32px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0);
  }
}

  .hzms_line{
    width: 5rem;
    height: 0.15rem;
    background-color: #01b077;
    margin: 1rem auto;
  }
.hzmsimg img{
  width: 100%;
}
  .hzmsimg{
    position: relative;
    opacity: 0;
    animation:hzmsimg 4s;
    animation-fill-mode: forwards;
    animation-delay:.8s;
  }
  .hzmsimganimation{
    -webkit-animation-name: -webkit-hzmsimganimation;
    animation-name: hzmsimganimation;
  }
@keyframes -webkit-hzmsimganimation{
  0% {
    opacity: 0;
    -webkit-transform: translateX(-32px);
    transform: translateX(-32px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateX(0);
    transform: translateX(0);

  }
}
@keyframes hzmsimganimation{
  0% {
    opacity: 0;
    -webkit-transform: translateX(-32px);
    -ms-transform: translateX(-32px);
    transform: translateX(-32px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0);
  }
}

</style>
