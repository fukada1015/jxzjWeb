<template>
    <div class="container">
      <div class="row">
        <div class="col-lg-12 wow jdystext jdystextanimation" data-wow-delay="1.2s"><span>强驻机械之家中心仓九大优势</span></div>
      </div>
      <div class="row">
        <div class="qgck_line"></div>
      </div>

      <div class="row">
        <div class="col-md-4">
          <div class="wow kapp kappanimation" data-wow-delay=".2s">
            <div class="row">
              <div class="col-md-2"><h1 class="dss">1</h1></div>
              <div class="col-md-10">
                <h5 class="tszz">管的准</h5>
                <p class="fbtzz">全程信息化流转，管理精准</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="wow kapp kappanimation" data-wow-delay=".4s">
            <div class="row">
              <div class="col-md-2"><h1 class="dss">2</h1></div>
              <div class="col-md-10">
                <h5 class="tszz">服务好</h5>
                <p class="fbtzz">高效工作，轻松管理汽配生意</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="wow kapp kappanimation" data-wow-delay=".6s">
            <div class="row">
              <div class="col-md-2"><h1 class="dss">3</h1></div>
              <div class="col-md-10">
                <h5 class="tszz">效率高</h5>
                <p class="fbtzz">智能分拣，极速出库</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-md-4">
          <div class="wow kapp kappanimation" data-wow-delay=".8s">
            <div class="row">
              <div class="col-md-2"><h1 class="dss">4</h1></div>
              <div class="col-md-10">
                <h5 class="tszz">柔性化</h5>
                <p class="fbtzz">轻松胜任订单大规模伸缩变化</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="wow kapp kappanimation" data-wow-delay="1s">
            <div class="row">
              <div class="col-md-2"><h1 class="dss">5</h1></div>
              <div class="col-md-10">
                <h5 class="tszz">节不停</h5>
                <p class="fbtzz">365天×24小时配送服务</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="wow kapp kappanimation" data-wow-delay="1.2s">
            <div class="row">
              <div class="col-md-2"><h1 class="dss">6</h1></div>
              <div class="col-md-10">
                <h5 class="tszz">不分心</h5>
                <p class="fbtzz">一站式管理，聚焦核心能力</p>
              </div>
            </div>
          </div>
        </div>
      </div>


      <div class="row">
        <div class="col-md-4">
          <div class="wow kapp kappanimation" data-wow-delay="1.4s">
            <div class="row">
              <div class="col-md-2"><h1 class="dss">7</h1></div>
              <div class="col-md-10">
                <h5 class="tszz">覆盖广</h5>
                <p class="fbtzz">全仓共享，业务覆盖全国</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="wow kapp kappanimation" data-wow-delay="1.6s">
            <div class="row">
              <div class="col-md-2"><h1 class="dss">8</h1></div>
              <div class="col-md-10">
                <h5 class="tszz">成本省</h5>
                <p class="fbtzz">仓储，物流成本大幅度降低</p>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="wow kapp kappanimation" data-wow-delay="1.8s">
            <div class="row">
              <div class="col-md-2"><h1 class="dss">9</h1></div>
              <div class="col-md-10">
                <h5 class="tszz">形象升</h5>
                <p class="fbtzz">标准化、智能化管理，提升品牌形象</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "jxzj_jdys"
    }
</script>

<style>
.jdystext{
  margin: 0 auto;
  letter-spacing: 0.2rem;
  text-align: center;
  font-size: 1.6rem;

}
.jdystextanimation{
  -webkit-animation-name: -webkit-jdystextanimation;
  animation-name: jdystextanimation;
}
@keyframes -webkit-jdystextanimation{
  0% {
    opacity: 0;
    -webkit-transform: translateY(-32px);
    transform: translateY(-32px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    transform: translateY(0);

  }
}
@keyframes jdystextanimation{
  0% {
    opacity: 0;
    -webkit-transform: translateY(-32px);
    -ms-transform: translateY(-32px);
    transform: translateY(-32px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0);
  }
}
  .kapp{
    width: 100%;
    padding-left:0rem;
    padding-top: 2rem;
    margin-top: 1.5rem;
  }
  .kappanimation{
    -webkit-animation-name: -webkit-kappanimation;
    animation-name: kappanimation;
  }
@keyframes -webkit-kappanimation{
  0% {
    opacity: 0;
    -webkit-transform: translateY(32px);
    transform: translateY(32px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    transform: translateY(0);

  }
}
@keyframes kappanimation{
  0% {
    opacity: 0;
    -webkit-transform: translateY(32px);
    -ms-transform: translateY(32px);
    transform: translateY(32px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0);
  }
}

.kapp:hover {
  z-index: 2;
  box-shadow: 1px 5px 10px 4px rgba(0, 0, 0, 0.1);
  -webkit-transition: all .5s;
  transition: all .5s;
}
.kapp:first-child:hover {
  z-index: 2;
  box-shadow: 1px 5px 10px 5px rgba(0, 0, 0, 0.05);
}
.tszz{
  color: #050000;
  letter-spacing: 0.1rem;
}
  .fbtzz{
    color: #859192;
    font-size: 1rem;
  }
  .dss{
    color: #00c587;
    text-align: center;
  }
</style>
