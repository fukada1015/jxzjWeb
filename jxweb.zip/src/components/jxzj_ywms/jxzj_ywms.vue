<template>
    <div class="container">
      <div class="row">
        <div class="col-lg-12 wow ywms1 ywmsanimations" data-wow-delay=".6s"><span>机械之家业务模式</span></div>
      </div>
      <div class="row">
        <div class="ywms_line"></div>
      </div>
      <div class="row">
        <div class="wow ywmsimg ywmsimganimgation" data-wow-delay=".8s"><img src="../../common/images/ywms1_03.png"/></div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "jxzj_ywms"
    }
</script>

<style>
.ywms1{
  margin: 0 auto;
  letter-spacing: 0.2rem;
  text-align: center;
  font-size: 1.6rem;

}
.ywmsanimations{
  -webkit-animation-name: -webkit-ywmsanimations;
  animation-name: ywmsanimations;
}
@keyframes -webkit-ywmsanimations{
  0% {
    opacity: 0;
    -webkit-transform: translateY(32px);
    transform: translateY(32px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    transform: translateY(0);

  }
}
@keyframes ywmsanimations{
  0% {
    opacity: 0;
    -webkit-transform: translateY(32px);
    -ms-transform: translateY(32px);
    transform: translateY(32px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0);
  }
}
  .ywms_line{
    width: 5rem;
    height: 0.15rem;
    background-color: #01b077;
    margin: 1rem auto;
  }
  .ywmsimg img{
    width: 100%;
  }
  .ywmsimg {

  }
  .ywmsimganimgation{
    -webkit-animation-name: -webkit-ywmsimganimgation;
    animation-name: ywmsimganimgation;
  }
@keyframes -webkit-ywmsimganimgation{
  0% {
    opacity: 0;
    -webkit-transform: translateY(32px);
    transform: translateY(32px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    transform: translateY(0);

  }
}
@keyframes ywmsimganimgation{
  0% {
    opacity: 0;
    -webkit-transform: translateY(32px);
    -ms-transform: translateY(32px);
    transform: translateY(32px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0);
  }
}

</style>
