<template>
    <div>
      <el-row>
        <el-col :span="15" class="zhengdi">

        </el-col>
        <el-col :span="9"></el-col>
      </el-row>
      <el-row type="flex" justify="center">
        <el-col :span="18">
          <el-container>
            <el-container>
              <el-header >

                <el-menu :default-active="activeIndex"  mode="horizontal" @select="handleSelect" active-text-color="#00b075" text-color="#838383"
                style="width: 95%;">
                  <el-menu-item style="margin-left: 7%" index="1">全部文章</el-menu-item>
                  <el-menu-item style="margin-left: 7%" index="2">内部新闻</el-menu-item>
                  <el-menu-item style="margin-left: 7%" index="3">行业动态</el-menu-item>
                  <el-menu-item style="margin-left: 7%" index="4">融资动态</el-menu-item>
                </el-menu>

              </el-header>
              <el-main >
                <div style="margin-top: -1rem">
                <el-container class="fenxian" v-for="(item,index) in showcont" :key="index">
                  <el-aside class="imgdingw"><img :src="item.imgurl" style="width: 300px;height: 188px"/>
                  </el-aside>
                  <el-main>
                    <router-link :to="'/newsinfo/'+ item.id" class="biansel"> <p class="dp1" >{{item.title}}</p></router-link>
                    <p class="dp2">{{item.contents}}</p>
                    <p class="dp3">{{item.datetime.substring(0,10)}}</p>
                  </el-main>
                </el-container>
                </div>
              </el-main>
              <div class="footer">
                <el-footer>
<!--                  <el-pagination layout="prev, pager, next" :page-size="6" :total="100"></el-pagination>-->
                  <el-pagination
                    @current-change="funtiaozhuan"
                    @size-change="handleSizeChange"
                    :current-page ="currentPage"
                    background
                    layout="prev, pager, next"
                    :page-size="6"
                    :total="mycounts">
                  </el-pagination>
                </el-footer>
              </div>
            </el-container>
            <el-aside>
              <div class="searchdiv">
                <el-autocomplete
                  popper-class="my-autocomplete"
                  v-model="state3"
                  :fetch-suggestions="querySearch"
                  placeholder="搜索文章"
                  @select="handleSelectsearch">
                  <i
                    class="el-icon-search el-input__icon"
                    slot="suffix"
                    @click="handleIconClick" style="line-height: 2rem">
                  </i>
                  <template slot-scope="props">
                    <div class="name">{{ props.item.value }}</div>
                    <span class="addr">{{ props.item.address }}</span>
                  </template>
                </el-autocomplete>
                <div class="rmwzdiv">
                  <p class="rmwztext"><span class="rmwz">|</span>热门词汇</p>
                </div>
                <div class="gjzding">
                  <span>资讯</span>
                  <span>内部新闻</span>
                  <span>行业动态</span>
                  <span>融资动态</span>
<!--                  <ul>-->
<!--                    <li>资讯</li>-->
<!--                    <li>内部新闻</li>-->
<!--                    <li>行业动态</li>-->
<!--                    <li>融资动态</li>-->
<!--                  </ul>-->
                </div>

              </div>
              <div class="rmwzlistt">
                <div class="rmwzdiv">
                  <p class="rmwztext"><span class="rmwz">|</span>热门文章</p>
                </div>
                <div class="seldingwei">
                <div class="rmwzjttitle" v-for="(item,index) in showcont" :key="index">
                  <router-link :to="'/newsinfo/'+ item.id" class="biansel"><p class="xyjstyle">{{item.title}}</p></router-link>
                  <p>{{item.datetime.substring(0,10)}}</p>
                </div>
                </div>
              </div>
            </el-aside>
          </el-container>
        </el-col>
      </el-row>
    </div>
</template>

<script>
  import axios from 'axios'
  import vueaxios from 'vue-axios'
  // t:new Date().getTime().toString(),
    export default {
      data() {
        return {
          activeIndex:'1',
          datacent:{},
          showcont:[],
          restaurants: [],
          state3: '',
          canshu:{
            mytype:'1',
            cont:'1',
          },
          mycounts:1,
          currentPage:1,
        }
      },
      methods: {
        handleSelect(key, keyPath) {

          this.canshu.mytype = key
          this.canshu.cont = '1'
          // console.log(key, keyPath);
          // this.getnewcut(key)
          // console.log(this.canshu);
          this.getinfo(this.canshu)

          // console.log(this.showcont.length);
        },
        querySearch(queryString, cb) {
          var restaurants = this.restaurants;
          var results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants;
          // 调用 callback 返回建议列表的数据
          cb(results);
        },
        createFilter(queryString) {
          return (restaurant) => {
            return (restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
          };
        },
        loadAll() {
          return [
            { "value": "三全鲜食（北新泾店）", "address": "长宁区新渔路144号" },
            { "value": "Hot honey 首尔炸鸡（仙霞路）", "address": "上海市长宁区淞虹路661号" },
            { "value": "新旺角茶餐厅", "address": "上海市普陀区真北路988号创邑金沙谷6号楼113" },
            { "value": "泷千家(天山西路店)", "address": "天山西路438号" },
            { "value": "胖仙女纸杯蛋糕（上海凌空店）", "address": "上海市长宁区金钟路968号1幢18号楼一层商铺18-101" },
            { "value": "贡茶", "address": "上海市长宁区金钟路633号" },
            { "value": "豪大大香鸡排超级奶爸", "address": "上海市嘉定区曹安公路曹安路1685号" },
            { "value": "茶芝兰（奶茶，手抓饼）", "address": "上海市普陀区同普路1435号" },
            { "value": "十二泷町", "address": "上海市北翟路1444弄81号B幢-107" },
            { "value": "星移浓缩咖啡", "address": "上海市嘉定区新郁路817号" },
            { "value": "阿姨奶茶/豪大大", "address": "嘉定区曹安路1611号" },
            { "value": "新麦甜四季甜品炸鸡", "address": "嘉定区曹安公路2383弄55号" },
            { "value": "Monica摩托主题咖啡店", "address": "嘉定区江桥镇曹安公路2409号1F，2383弄62号1F" },
            { "value": "浮生若茶（凌空soho店）", "address": "上海长宁区金钟路968号9号楼地下一层" },
            { "value": "NONO JUICE  鲜榨果汁", "address": "上海市长宁区天山西路119号" },
            { "value": "CoCo都可(北新泾店）", "address": "上海市长宁区仙霞西路" },
            { "value": "快乐柠檬（神州智慧店）", "address": "上海市长宁区天山西路567号1层R117号店铺" },
            { "value": "Merci Paul cafe", "address": "上海市普陀区光复西路丹巴路28弄6号楼819" },
            { "value": "猫山王（西郊百联店）", "address": "上海市长宁区仙霞西路88号第一层G05-F01-1-306" },
            { "value": "枪会山", "address": "上海市普陀区棕榈路" },
            { "value": "纵食", "address": "元丰天山花园(东门) 双流路267号" },
            { "value": "钱记", "address": "上海市长宁区天山西路" },
            { "value": "壹杯加", "address": "上海市长宁区通协路" },
            { "value": "唦哇嘀咖", "address": "上海市长宁区新泾镇金钟路999号2幢（B幢）第01层第1-02A单元" },
            { "value": "爱茜茜里(西郊百联)", "address": "长宁区仙霞西路88号1305室" },
            { "value": "爱茜茜里(近铁广场)", "address": "上海市普陀区真北路818号近铁城市广场北区地下二楼N-B2-O2-C商铺" },
            { "value": "鲜果榨汁（金沙江路和美广店）", "address": "普陀区金沙江路2239号金沙和美广场B1-10-6" },
            { "value": "开心丽果（缤谷店）", "address": "上海市长宁区威宁路天山路341号" },
            { "value": "超级鸡车（丰庄路店）", "address": "上海市嘉定区丰庄路240号" },
            { "value": "妙生活果园（北新泾店）", "address": "长宁区新渔路144号" },
            { "value": "香宜度麻辣香锅", "address": "长宁区淞虹路148号" },
            { "value": "凡仔汉堡（老真北路店）", "address": "上海市普陀区老真北路160号" },
          ];
        },
        handleSelectsearch(item) {
          console.log(item);
        },
        handleIconClick(ev) {
          console.log(ev);
        },
        async getinfo(obj){
          this.showcont = []
          this.mycounts = 0
          let result = await this.$axios.get('http://39.96.43.242/getinfo',{params:obj})
          console.log( result)
          this.mycounts = result.data.tiaoshu
          for(let i = 0; i < result.data.data.length; i++){
            this.showcont.push(result.data.data[i])
          }
         this.currentPage = parseInt(obj.cont)
        },
        shownews(n){
          // console.log(n)

        },

        funtiaozhuan(val){
          this.canshu.cont = val.toString()
          console.log(this.canshu.cont)

            this.hanshu()
          // this.currentPage4 = val
          // this.canshu.cont = val
          // console.log(this.canshu)
          // this.getinfo(this.canshu)
        },
        hanshu(){
          this.getinfo(this.canshu)
        },
        handleSizeChange(val) {
          console.log(`每页 ${val} 条`);
        },
      },
      created() {
      },
      mounted() {
        this.restaurants = this.loadAll()
        this.getinfo(this.canshu)

      }
    }
</script>

<style>
  .zhengdi{
    margin-top: 4rem;
  }
  .imgdingw{
    width: 40%;
    margin-top: 1.9rem;
  }
.imgdingw img{
  width: 100%;
}
  .dp1 {
    font-size: 1.8rem;
    color: #2e4446;

  }
  .dp1:active {
    color: #2e4446;
  }
  .xyjstyle{
    color: #2e4446;
  }
  .dp2{
    font-size: 0.8rem;
    color: #6c7c7d;
    letter-spacing: 0.1rem;
    font-weight: bold;
  }
  .dp3{
    font-size: 0.8rem;
    color: #6c7c7d;
    letter-spacing: 0.1rem;
  }
  .fenxian{
    border-bottom: 0.1rem solid #ecf0f5;
    padding-bottom: 2rem;

  }
  .biansel:hover p{
    color: #04cb94;
  }
  .biansel:link, .biansel:hover, .biansel:visited, .biansel:active {
    text-decoration:none;
  }

  .el-pagination{
    text-align: center;
  }
  .el-pagination li.active {
    background: #01b077 !important;
  }
  .searchdiv {
    margin-top: 1rem;
    margin-left: 0.5rem;
    padding-top: 2rem;
    padding-left: 0.5rem;
    width: 95%;

    -moz-box-shadow:0px 0px 0.8em #e2e3e5;
    -webkit-box-shadow:0px 0px 0.8em #e2e3e5;
    box-shadow:0px 0px 0.8em #e2e3e5;
    padding-bottom: 15%;

  }
  .searchdiv input {
    height: 2rem;
    width: 15.5rem;
  }

  .my-autocomplete li{
    line-height: normal;
    padding: 7px;
  }
  .my-autocomplete li .name{
    text-overflow: ellipsis;
    overflow: hidden;
  }
  .my-autocomplete li .addr{
    font-size: 12px;
    color: #b4b4b4;
  }
  .my-autocomplete li .highlighted .addr{
    color: #ddd;
  }
.rmwz{
  /*color: #04cb94;*/
  font-weight: bold;
  margin-right: 1rem;
}
  .rmwztext{
    color: #2e4446;

  }
  .rmwzdiv{
    border-bottom: 0.1rem solid #ecf0f5;
    margin-top: 1rem;
    width: 90%;
  }
  .gjzding{
    margin-top: 0.7rem;
  }
  .gjzding span{
    color: #465759;
    font-size: 0.7rem;
    margin-right: 1rem;
  }
  .rmwzlistt{
    margin-top: 3rem;
    -moz-box-shadow:0px 0px 0.8em #e2e3e5;
    -webkit-box-shadow:0px 0px 0.8em #e2e3e5;
    box-shadow:0px 0px 0.8em #e2e3e5;
    width: 95%;
    margin-left: 0.5rem;
    padding-top: 1rem;
    padding-left: 0.5rem;
    padding-bottom: 1rem;
  }
  .rmwzjttitle p{
    font-size: 0.8rem;
    width: 90%;
    /*color: #04cb94;*/
  }

  .seldingwei{
    margin-top: 1rem;
    margin-left: 0.7rem;
  }
  .footer .el-pagination li.active {
    background: #01b077 !important;
    color: white !important;
  }
  .el-pagination li {
    border-radius: 8px;
  }
</style>
