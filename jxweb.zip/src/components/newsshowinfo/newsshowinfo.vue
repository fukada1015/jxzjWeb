<template>
  <div>
    <el-row>
      <el-col :span="15" class="zhengdi">

      </el-col>
      <el-col :span="9"></el-col>
    </el-row>
    <el-row type="flex" justify="center">
      <el-col :span="18">
        <el-container>
          <el-container>
            <el-header style="border-bottom: 1px solid #ecf0f5">

              <el-menu router :default-active="activeIndex"  mode="horizontal" @select="handleSelect" active-text-color="#00b075" text-color="#838383"
                       style="width: 95%;">
                <el-menu-item style="margin-left: 6rem" index="/news">全部文章</el-menu-item>
                <el-menu-item style="margin-left: 6rem" index="/news">内部新闻</el-menu-item>
                <el-menu-item style="margin-left: 6rem" index="/news">行业动态</el-menu-item>
                <el-menu-item style="margin-left: 6rem" index="/news">融资动态</el-menu-item>
              </el-menu>
            </el-header>
            <el-main>
              <div><p class="bigclass"></p></div>
              <div><p class="bigclass"></p></div>
              <div><p class="bigclass">{{newsinfos[0].title}}</p></div>
              <el-row class="huaxian">
                <el-col :span="1"><img src="../../common/images/newcontimg_03.gif" height="30" width="30"/></el-col>
                <el-col :span="2"><p class="rmch" style="line-height: 30px">热门词汇:</p></el-col>
                <el-col :span="15"><p class="rmch" style="line-height: 30px">{{newsinfos[0].title}}<span>&nbsp;&nbsp;|&nbsp;&nbsp;</span>{{newsinfos[0].datetime.substring(0,10)}}</p></el-col>
<!--                <el-col :span="20"><p class="rmch"><span>&nbsp;|&nbsp;</span></p></el-col>-->
              </el-row>
              <div></div>
              <div>{{newsinfos[0].contents}}</div>
            </el-main>
            <div class="footer">
              <el-footer>
                <el-button class="mybuttom" @click="prepian">＜上一篇</el-button>
                <el-button class="mybuttom" @click="nextpian">下一篇＞</el-button>
              </el-footer>
            </div>
          </el-container>
          <el-aside>
            <div class="searchdiv">
              <el-autocomplete
                popper-class="my-autocomplete"
                v-model="state3"
                :fetch-suggestions="querySearch"
                placeholder="搜索文章"
                @select="handleSelectsearch">
                <i
                  class="el-icon-search el-input__icon"
                  slot="suffix"
                  @click="handleIconClick">
                </i>
                <template slot-scope="props">
                  <div class="name">{{ props.item.value }}</div>
                  <span class="addr">{{ props.item.address }}</span>
                </template>
              </el-autocomplete>
              <div class="rmwzdiv">
                <p class="rmwztext"><span class="rmwz">|</span>热门词汇</p>
              </div>
              <div class="gjzding">
                <span>资讯</span>
                <span>内部新闻</span>
                <span>行业动态</span>
                <span>融资动态</span>
                <!--                  <ul>-->
                <!--                    <li>资讯</li>-->
                <!--                    <li>内部新闻</li>-->
                <!--                    <li>行业动态</li>-->
                <!--                    <li>融资动态</li>-->
                <!--                  </ul>-->
              </div>

            </div>
            <div class="rmwzlistt">
              <div class="rmwzdiv">
                <p class="rmwztext"><span class="rmwz">|</span>热门文章</p>
              </div>
              <div class="seldingwei">
                <div class="rmwzjttitle" v-for="(item,index) in datacent" :key="index">
<!--                  <router-link :to="'/newsinfo/'+ item.id" class="bianse5"> <p class="xyjstyle2">{{item.title}}</p></router-link>-->
                  <a href="javascript:;" class="ceshid" @click="dankan(item.id)"><p class="xyjstyle2">{{item.title}}</p></a>
                    <p class="xyjstyle2" >{{item.datetime.substring(0,10)}}</p>
                </div>
              </div>
            </div>
          </el-aside>
        </el-container>
      </el-col>
    </el-row>
  </div>
</template>

<script>
  import axios from 'axios'
  import vueaxios from 'vue-axios'
    export default {
        data(){
          return{
            state3: '',
            activeIndex: '1',
            pathobj:{
              path:'/news'
            },
            newsinfos:{},
            datacent:{},
            canshu:{
              cont:'1',
              mytype:'1',
              // t:new Date().getTime().toString(),
            },
            newid:{
              myid:'1',
              // t:new Date().getTime().toString(),
            }

          }
        },
      methods:{
        handleSelect(key, keyPath) {
          this.canshu.mytype = key.toString()
          this.canshu.cont = '1'
          // console.log(key, keyPath);
          // this.getnewcut(key)
          // console.log(this.canshu);
          // this.getinfo(this.canshu)



          // // console.log(key, keyPath);
          // this.getnewcut(key)
          // console.log(this.datacent);
        },
        querySearch(queryString, cb) {
          var restaurants = this.restaurants;
          var results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants;
          // 调用 callback 返回建议列表的数据
          cb(results);
        },
        createFilter(queryString) {
          return (restaurant) => {
            return (restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
          };
        },
        loadAll() {
          return [
            { "value": "三全鲜食（北新泾店）", "address": "长宁区新渔路144号" },
            { "value": "Hot honey 首尔炸鸡（仙霞路）", "address": "上海市长宁区淞虹路661号" },
            { "value": "新旺角茶餐厅", "address": "上海市普陀区真北路988号创邑金沙谷6号楼113" },
            { "value": "泷千家(天山西路店)", "address": "天山西路438号" },
            { "value": "胖仙女纸杯蛋糕（上海凌空店）", "address": "上海市长宁区金钟路968号1幢18号楼一层商铺18-101" },
            { "value": "贡茶", "address": "上海市长宁区金钟路633号" },
            { "value": "豪大大香鸡排超级奶爸", "address": "上海市嘉定区曹安公路曹安路1685号" },
            { "value": "茶芝兰（奶茶，手抓饼）", "address": "上海市普陀区同普路1435号" },
            { "value": "十二泷町", "address": "上海市北翟路1444弄81号B幢-107" },
            { "value": "星移浓缩咖啡", "address": "上海市嘉定区新郁路817号" },
            { "value": "阿姨奶茶/豪大大", "address": "嘉定区曹安路1611号" },
            { "value": "新麦甜四季甜品炸鸡", "address": "嘉定区曹安公路2383弄55号" },
            { "value": "Monica摩托主题咖啡店", "address": "嘉定区江桥镇曹安公路2409号1F，2383弄62号1F" },
            { "value": "浮生若茶（凌空soho店）", "address": "上海长宁区金钟路968号9号楼地下一层" },
            { "value": "NONO JUICE  鲜榨果汁", "address": "上海市长宁区天山西路119号" },
            { "value": "CoCo都可(北新泾店）", "address": "上海市长宁区仙霞西路" },

          ];
        },
        handleSelectsearch(item) {
          console.log(item);
        },
        handleIconClick(ev) {
          console.log(ev);
        },
        querynews(){
          this.$axios.get('http://39.96.43.242/hotnews',{}).then((response)=>{
            // console.log(response);

            this.datacent = response.data
            console.log(this.datacent);

          }).catch((error)=>{
            console.log(error);
          })
        },
        newsinfo(){
          this.$axios.get('http://39.96.43.242/getnews',{params:{...this.newid}}).then((response)=>{
            // console.log(response);

            this.newsinfos = response.data
            console.log(this.newsinfos);
          }).catch((error)=>{
            console.log(error);
          })
        },
        prepian(){
          this.newid.myid = String(parseInt(this.newid.myid) - 1)
          this. newsinfo()
        },
        nextpian(){
          this.newid.myid = String(parseInt(this.newid.myid) + 1)
          this. newsinfo()
        },
        dankan(n){
          this.newid.myid = String(n)
          this.newsinfo()
        }
      },
      mounted() {
          // console.log(this.$route.params.id)  // 1
        this.newid.myid = String(this.$route.params.id)
        console.log(this.newid.myid);
        this.newsinfo()
        this.querynews()
      }
    }
</script>

<style>
  .zhengdi{
    margin-top: 4rem;
  }
  .imgdingw{
    width: 40%;
  }
  .imgdingw img{
    width: 100%;
  }
  .dp1 {
    font-size: 1.8rem;
    /*color: #04cb94;*/
    color: #2e4446;

  }
  .dp2{
    font-size: 0.8rem;
    color: #6c7c7d;
    letter-spacing: 0.1rem;
    font-weight: bold;
  }
  .dp3{
    font-size: 0.8rem;
    color: #6c7c7d;
    letter-spacing: 0.1rem;
  }
  .fenxian{
    border-bottom: 0.1rem solid #ecf0f5;
    padding-bottom: 1rem;
    margin-top: 1rem;
  }
  .el-pagination{
    text-align: center;
  }
  .el-pagination li.active {
    background: #01b077 !important;
  }
  .searchdiv {
    margin-top: 1rem;
    margin-left: 0.5rem;
    padding-top: 2rem;
    padding-left: 0.5rem;
    width: 95%;

    -moz-box-shadow:0px 0px 0.8em #e2e3e5;
    -webkit-box-shadow:0px 0px 0.8em #e2e3e5;
    box-shadow:0px 0px 0.8em #e2e3e5;
    padding-bottom: 15%;

  }
  .searchdiv input {
    height: 2rem;
  }

  .my-autocomplete li{
    line-height: normal;
    padding: 7px;
  }
  .my-autocomplete li .name{
    text-overflow: ellipsis;
    overflow: hidden;
  }
  .my-autocomplete li .addr{
    font-size: 12px;
    color: #b4b4b4;
  }
  .my-autocomplete li .highlighted .addr{
    color: #ddd;
  }
  a:hover p{
    color: #04cb94;
  }
  a:link, a:hover, a:visited, a:active {
    text-decoration:none;
  }
  .rmwz{
    color: #04cb94;
    font-weight: bold;
    margin-right: 1rem;
  }
  .rmwztext{
    color: #2e4446;

  }
  .rmwzdiv{
    border-bottom: 0.1rem solid #ecf0f5;
    margin-top: 1rem;
    width: 90%;
  }
  .gjzding{
    margin-top: 0.7rem;
  }
  .gjzding span{
    color: #465759;
    font-size: 0.7rem;
    margin-right: 1rem;
  }
  .rmwzlistt{
    margin-top: 3rem;
    -moz-box-shadow:0px 0px 0.8em #e2e3e5;
    -webkit-box-shadow:0px 0px 0.8em #e2e3e5;
    box-shadow:0px 0px 0.8em #e2e3e5;
    width: 95%;
    margin-left: 0.5rem;
    padding-top: 1rem;
    padding-left: 0.5rem;
    padding-bottom: 1rem;
  }
  .rmwzjttitle p{
    font-size: 0.8rem;
    width: 90%;
    /*color: #04cb94;*/
  }
  .seldingwei{
    margin-top: 1rem;
    margin-left: 0.7rem;
  }
  .footer .el-pagination li.active {
    background: #01b077 !important;
    color: white !important;
  }
  .el-pagination li {
    border-radius: 8px;
  }
  .bigclass{
    color: #52645e;
    font-size: 2.5rem;
    font-weight: bold;
  }
  .rmch {
    color: #a5adb2;
    font-size: 1rem;
  }
.huaxian{
  border-bottom: 1px solid #ecf0f5;
}
  .mybuttom:hover {
    background-color: #39c195;
    color: white;
  }
  .bianse5:hover p{
    color: #04cb94;
  }
  .bianse5:link, .biansel:hover, .biansel:visited, .biansel:active {
    text-decoration:none;
  }
  .xyjstyle2{
    color: #2e4446;
  }
</style>
