<template>
    <div class="rongzibannerbg">
      <div class="container">
        <div class="carousel" @mouseenter="enter" @mouseleave="leave">
          <transition-group
            tag="ul"
            name="image"
            enter-active-class="animated lightSpeedIn"
            leave-active-class="animated lightSpeedOut"
          >
            <li v-for='(images,indexs) in img' :key='indexs' v-show="indexs === mark">
              <a href="javascript:;">
                <img :src="images" class="img-responsive">
              </a>
            </li>
          </transition-group>
<!--          <div class="bullet">-->
<!--        <span v-for="(item,index) in img.length" :class="{'active':index === mark}"-->
<!--              @click="change(index)" :key="index"></span>-->
<!--          </div>-->
<!--          <div class="switch">-->
<!--            <span class="prev" @click="prev">&lt;</span>-->
<!--            <span class="next" @click="next">&gt;</span>-->
<!--          </div>-->
        </div>
      </div>
     </div>

</template>

<script>

    export default {
        name: "rongziimgban",
      data(){
          return{
            mark:0,
            img:[
              './static/rongyuaboutusimg_04.png',
              './static/rongyuaboutusimg_08.png',
            ],
            time:null
          }
      },
      methods:{
        change(i){
          this.mark = i;
        },
        prev(){
          this.mark--;
          if(this.mark === -1){
            this.mark = 3;
            return
          }
        },
        next(){
          this.mark++;
          if(this.mark === 4){
            this.mark = 0;
            return
          }
        },
        autoPlay(){
          this.mark++;
          if(this.mark === 2){
            this.mark = 0;
            return
          }
        },
        play(){
          this.time = setInterval(this.autoPlay,3000);
        },
        enter(){
          console.log('enter')
          clearInterval(this.time);
        },
        leave(){
          console.log('leave')
          this.play();
        }
      },
      created(){
        this.play()
      }
    }
</script>

<style>
.rongzibannerbg{
  background-color: #f8fbfc;
  /*position: relative;*/
}
li{
  list-style: none;
}
.carousel{
  width: 100%;
  height: 100%;
  /*height: 65.5rem;*/
  /*height: 100%;*/
  padding-bottom: 90%;
  overflow: hidden;
  /*margin: 100px auto;*/
  /*position: relative;*/
}


.carousel ul{
  width: 100%;
}
.carousel ul li{
  position: absolute;
}
.carousel ul li a img{
  width: 100%;
  /*height: 300px;*/
}
/*.bullet{*/
/*  position: absolute;*/
/*  font-size: 0;*/
/*  bottom: 20px;*/
/*  left: 50%;*/
/*  margin-left: -42px;*/
/*}*/
/*.bullet span{*/
/*  display: inline-block;*/
/*  width: 10px;*/
/*  height: 10px;*/
/*  background-color: #ffffff;*/
/*  margin-left: 15px;*/
/*  border-radius: 10px;*/
/*}*/
/*.bullet span:first-child{*/
/*  margin-left: 0;*/
/*}*/
/*.switch{*/

/*}*/
/*.switch span{*/
/*  position: absolute;*/
/*  width: 50px;*/
/*  height: 50px;*/
/*  line-height: 50px;*/
/*  text-align: center;*/
/*  background-color: rgba(0,0,0,.1);*/
/*  font-size: 20px;*/
/*  color: #ffffff;*/
/*  top: 50%;*/
/*  margin-top: -25px;*/
/*  cursor: pointer;*/
/*  font-family: "微软雅黑";*/
/*}*/
/*.switch span:hover{*/

/*  background-color: rgba(0,0,0,.5);*/

/*}*/
/*.prev{*/
/*  left: 0;*/
/*}*/
/*.next{*/
/*  right: 0;*/
/*}*/

</style>
