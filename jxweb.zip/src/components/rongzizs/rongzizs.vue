<template>
    <div class="container">
      <div class="row">
        <div class="col-lg-12 wow rongyutitle rongyutitlanimation" data-wow-delay=".6s"><span>四轮融资，独角兽潜质备受投资机构青睐</span></div>
      </div>
      <div class="row">
        <div class="cptyline"></div>
      </div>
<!--      <div class="row">-->

<!--          <div class="col-lg-3 rongziimgcenter item001"><img src="../../common/images/rongzi1_03.jpg" /></div>-->
<!--          <div class="col-lg-3 rongziimgcenter item001"><img src="../../common/images/rongzi1_04.jpg" /></div>-->
<!--          <div class="col-lg-3 rongziimgcenter item001"><img src="../../common/images/rongzi1_05.jpg" /></div>-->
<!--          <div class="col-lg-3 rongziimgcenter item001"><img src="../../common/images/rongzi1_06.jpg" /></div>-->
<!--      </div>-->
      <el-row>
        <el-col :span="6" class="rongziimgcenter item001"><img src="../../common/images/rongzi1_03.jpg" /></el-col>
        <el-col :span="6" class="rongziimgcenter item001"><img src="../../common/images/rongzi1_04.jpg" /></el-col>
        <el-col :span="6" class="rongziimgcenter item001"><img src="../../common/images/rongzi1_05.jpg" /></el-col>
        <el-col :span="6" class="rongziimgcenter item001"><img src="../../common/images/rongzi1_06.jpg" /></el-col>
      </el-row>
      <div class="row dingwei2">
        <div class="col-lg-12 wow rongyutitle rongyutitlanimation" data-wow-delay=".8s"><span>公司概况</span></div>
      </div>
      <div class="row">
        <div class="cptyline"></div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "rongzizs"
    }
</script>

<style>
.rongyutitle{
  margin: 0 auto;
  letter-spacing: 0.2rem;
  text-align: center;
  font-size: 1.6rem;

}
.rongyutitlanimation{
  -webkit-animation-name: -webkit-rongyutitlanimation;
  animation-name: rongyutitlanimation;
}
@keyframes -webkit-rongyutitlanimation{
  0% {
    opacity: 0;
    -webkit-transform: translateY(32px);
    transform: translateY(32px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    transform: translateY(0);

  }
}
@keyframes rongyutitlanimation{
  0% {
    opacity: 0;
    -webkit-transform: translateY(32px);
    -ms-transform: translateY(32px);
    transform: translateY(32px);
  }

  100% {
    opacity: 1;
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0);
  }
}

  .cptyline{
    width: 5rem;
    height: 0.15rem;
    background-color: #01b077;
    margin: 1rem auto;
  }
  .rongziimgcenter{
    text-align: center;
    margin-top: 3rem;
    position: relative;

  }
.rongziimgcenter img {
    width: 100%;
}
  .rongziimgcenter:hover {
    z-index: 10;
    transform:scale(1.1,1.1);
    box-shadow: 0 5px 5px 0 rgba(0, 0, 0, 0.05);
    -webkit-transition: all .5s;
    transition: all .5s;
  }
/*.rongziimgcenter:first-child:hover {*/
/*    z-index: 10;*/
/*    box-shadow: 0 30px 40px 0 rgba(233, 188, 113, 0.15);*/
/*}*/
  .item001{
    -webkit-transition: all .5s;
    transition: all .5s;
    padding-top: 0;
  }
.dingwei2{
  margin-top: 6rem;
}
</style>
