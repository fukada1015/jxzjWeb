<template>
    <div class="zsnsbn_bg">
      <div class="container wzding">
          <div><p>去相信，去证明</p></div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "zsns_banner"
    }
</script>

<style>
.zsnsbn_bg{
  width: 100%;
  background: url("../../common/images/zsnsbn_bg_02.jpg") center no-repeat;
  height: 100%;
  padding-bottom: 13%;
  padding-top: 13%;
}
  .wzding{
    text-align: center;
  }
  .wzding p {
    font-size: 2rem;
    color: white;
    letter-spacing: 0.5rem;
  }
</style>
