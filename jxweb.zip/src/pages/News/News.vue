<template>
    <div>
      <el-row class="newtopbg" >
      </el-row>
      <el-row type="flex" justify="center" >
        <el-col :span="12" class="navdingwei" >
          <topnav class="newtopdingwei" ></topnav>
        </el-col>
      </el-row>
      <youshangkuang></youshangkuang>
      <newscontain class="newsnrdignwei"></newscontain>
      <fanhuishouding6></fanhuishouding6>
      </div>


</template>

<script>
  import FooterGuide from '../../components/FooterGuide/FooterGuide'
  import topnav from '../../components/Banner/Banner'
  import newscontain from '../../components/newscontain/newscontain'
  import youshangkuang from '../../components/youshangtupian/youshangtupian'
  import fanhuishouding6 from '../../components/fanhuiding/fanhuiding'
    export default {
        name: "News",
      components:{
        FooterGuide,
        topnav,
        newscontain,
        youshangkuang,
        fanhuishouding6,
      }
    }
</script>

<style>
.newtopbg{
  width: 100%;
  background-color: #39c195;
  padding-bottom: 5rem;
  z-index: -1;
  position: absolute;
}
.navdingwei{
  margin-top: 0.5rem;
}
  .newtopdingwei{
    position: absolute;
    top: 0;
  }
  .newsnrdignwei{
    margin-top: 5rem;
  }
</style>
